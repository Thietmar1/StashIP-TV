var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod2) => __copyProps(__defProp({}, "__esModule", { value: true }), mod2);

// iptv/index.js
var index_exports = {};
__export(index_exports, {
  StashRequestError: () => StashRequestError,
  createIptvServer: () => createIptvServer,
  createMediaProxy: () => createMediaProxy,
  createStashClient: () => createStashClient,
  endpoint: () => endpoint,
  ffmpegArgs: () => ffmpegArgs,
  loadGuide: () => loadGuide,
  nextMidnight: () => nextMidnight,
  playableChannels: () => playableChannels,
  pluginConfig: () => pluginConfig,
  readConfig: () => readConfig,
  readInput: () => readInput,
  renderM3u: () => renderM3u,
  renderXmltv: () => renderXmltv,
  runPluginTask: () => runPluginTask,
  sendProgramme: () => sendProgramme,
  stashHeaders: () => stashHeaders,
  stashMediaUrl: () => stashMediaUrl,
  streamChannel: () => streamChannel,
  xml: () => xml,
  xmlTime: () => xmlTime
});
module.exports = __toCommonJS(index_exports);

// iptv/config.js
function httpUrl(value, name) {
  let url;
  try {
    url = new URL(value);
  } catch {
    throw new Error(`${name} must be an absolute HTTP(S) URL`);
  }
  if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || url.search || url.hash) {
    throw new Error(`${name} must be HTTP(S), without credentials, query or fragment`);
  }
  return url.href.replace(/\/$/, "");
}
function integer(value, fallback, min, max, name) {
  const n = value === void 0 ? fallback : Number(value);
  if (!Number.isInteger(n) || n < min || n > max) throw new Error(`Invalid ${name}`);
  return n;
}
function readConfig(env = process.env) {
  const token = env.TVGUIDE_TOKEN || "";
  if (!/^[A-Za-z0-9_-]{24,}$/.test(token)) throw new Error("TVGUIDE_TOKEN needs at least 24 letters, digits, hyphens or underscores");
  return {
    stashUrl: httpUrl(env.STASH_URL || "http://127.0.0.1:9999", "STASH_URL"),
    apiKey: env.STASH_API_KEY || "",
    sessionCookie: env.STASH_SESSION_COOKIE || "",
    publicUrl: httpUrl(env.TVGUIDE_PUBLIC_URL || "http://127.0.0.1:9898", "TVGUIDE_PUBLIC_URL"),
    host: env.TVGUIDE_HOST || "127.0.0.1",
    port: integer(env.TVGUIDE_PORT, 9898, 1, 65535, "TVGUIDE_PORT"),
    days: integer(env.TVGUIDE_EPG_DAYS, 3, 1, 7, "TVGUIDE_EPG_DAYS"),
    maxStreams: integer(env.TVGUIDE_MAX_STREAMS, 2, 1, 32, "TVGUIDE_MAX_STREAMS"),
    ffmpeg: env.FFMPEG_PATH || "ffmpeg",
    token
  };
}
function stashHeaders(config) {
  return config.apiKey ? { ApiKey: config.apiKey } : config.sessionCookie ? { Cookie: config.sessionCookie } : {};
}
function endpoint(config, path) {
  const url = new URL(`${config.publicUrl}${path}`);
  url.searchParams.set("token", config.token);
  return url.href;
}
function stashMediaUrl(config, value) {
  const url = new URL(value, `${config.stashUrl}/`);
  if (url.origin !== new URL(config.stashUrl).origin || !["http:", "https:"].includes(url.protocol)) {
    throw new Error("Stash returned a media URL outside STASH_URL; check its external host setting");
  }
  return url.href;
}
var StashRequestError = class extends Error {
};
function apiMessage(config, text) {
  let message = String(text);
  const cookieValue = config.sessionCookie?.slice(config.sessionCookie.indexOf("=") + 1);
  for (const secret of [config.apiKey, config.sessionCookie, cookieValue, config.token]) {
    if (secret) message = message.split(secret).join("[redacted]");
  }
  return message.replace(/https?:\/\/[^\s<>"']+/gi, "[URL redacted]").slice(0, 1e3);
}
function createStashClient(config, fetchFn = fetch) {
  return async (query, variables) => {
    const operation = /(?:query|mutation)\s+(\w+)/.exec(query)?.[1] || "GraphQL";
    const fail = (message) => new StashRequestError(`${operation}: ${apiMessage(config, message)}`);
    let response;
    try {
      response = await fetchFn(`${config.stashUrl}/graphql`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...stashHeaders(config) },
        body: JSON.stringify({ query, variables }),
        redirect: "error",
        signal: AbortSignal.timeout(3e4)
      });
    } catch {
      throw fail("Stash network request failed or timed out");
    }
    if (!response.ok) throw fail(`Stash GraphQL HTTP ${response.status}`);
    let body;
    try {
      body = await response.json();
    } catch {
      throw fail("Stash returned invalid JSON");
    }
    if (Array.isArray(body.errors) && body.errors.length) {
      throw fail(`Stash rejected the TVGuide GraphQL request: ${body.errors.map((error) => error.message || "Unknown GraphQL error").join("; ")}`);
    }
    if (!body.data) throw fail("Stash rejected the TVGuide GraphQL request: no data returned");
    return body.data;
  };
}

// iptv/server.js
var import_node_http2 = require("node:http");
var import_node_crypto2 = require("node:crypto");

// src/api/settings.js
var SETTING_KEYS = {
  guide_12_hour_clock: "guide_01_12_hour_clock",
  guide_autoplay: "guide_02_autoplay",
  guide_channel_info: "guide_03_channel_info",
  guide_start_muted: "guide_04_start_muted",
  guide_navbar_button: "guide_05_navbar_button",
  guide_sfw_text: "guide_06_sfw_text",
  guide_min_scenes: "guide_07_min_scenes",
  guide_window_hours: "guide_08_window_hours",
  guide_pool_cap: "guide_09_pool_cap",
  guide_new_release_days: "guide_10_new_release_days",
  guide_recently_added_days: "guide_11_recently_added_days",
  guide_movie_min_minutes: "guide_12_movie_min_minutes",
  guide_short_max_minutes: "guide_13_short_max_minutes",
  guide_short_scene_minutes: "guide_14_short_scene_minutes"
};
var DEFAULT_SETTINGS = {
  guide_min_scenes: 5,
  guide_window_hours: 3,
  guide_12_hour_clock: true,
  guide_pool_cap: 100,
  guide_new_release_days: 30,
  guide_recently_added_days: 14,
  guide_movie_min_minutes: 90,
  guide_short_max_minutes: 5,
  guide_short_scene_minutes: 15,
  guide_autoplay: true,
  guide_start_muted: true,
  guide_navbar_button: true,
  guide_channel_info: true,
  guide_sfw_text: false
};
var NUMBER_BOUNDS = {
  guide_min_scenes: { min: 0, max: 1e5 },
  guide_window_hours: { min: 1, max: 12 },
  guide_pool_cap: { min: 1, max: 1e3 },
  guide_new_release_days: { min: 0, max: 3650 },
  guide_recently_added_days: { min: 0, max: 3650 },
  guide_movie_min_minutes: { min: 1, max: 1440 },
  guide_short_max_minutes: { min: 1, max: 1440 },
  guide_short_scene_minutes: { min: 1, max: 30 }
};
var owns = (object, key) => Object.prototype.hasOwnProperty.call(object, key);
function coerce(key, raw) {
  const fallback = DEFAULT_SETTINGS[key];
  if (raw == null || typeof raw === "string" && !raw.trim()) return fallback;
  if (typeof fallback === "boolean") {
    return typeof raw === "boolean" ? raw : fallback;
  }
  const n = Number(raw);
  if (!Number.isFinite(n)) return fallback;
  const { min, max } = NUMBER_BOUNDS[key];
  return Math.min(max, Math.max(min, Math.round(n)));
}
function normalizeSettings(stored) {
  const source = stored && typeof stored === "object" ? stored : {};
  const out = {};
  for (const key of Object.keys(DEFAULT_SETTINGS)) {
    const storedKey = owns(source, SETTING_KEYS[key]) ? SETTING_KEYS[key] : key;
    out[key] = owns(source, storedKey) ? coerce(key, source[storedKey]) : DEFAULT_SETTINGS[key];
  }
  return out;
}

// src/domain/allScenes.js
var ALL_SCENES_CHANNEL_ID = "special:all-scenes";
var ALL_SCENES_EPOCH_MS = Date.UTC(2020, 0, 1);

// src/domain/schedule.js
function hashString(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
function mulberry32(seed) {
  let a = seed >>> 0;
  return function next() {
    a = a + 1831565813 >>> 0;
    let t = a;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function seededShuffle(items, seed) {
  const out = items.slice();
  const rng = mulberry32(seed);
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = out[i];
    out[i] = out[j];
    out[j] = tmp;
  }
  return out;
}
function dayBucket(nowMs) {
  const d = new Date(nowMs);
  const start = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0, 0);
  const pad = (n) => String(n).padStart(2, "0");
  return {
    key: `${start.getFullYear()}-${pad(start.getMonth() + 1)}-${pad(start.getDate())}`,
    startMs: start.getTime()
  };
}
function durationMsOf(scene) {
  const seconds = scene && scene.files && scene.files[0] && scene.files[0].duration;
  return typeof seconds === "number" && seconds > 0 ? Math.max(1, Math.round(seconds * 1e3)) : 0;
}
function buildDaySchedule(channelId, scenes, dayKey) {
  const continuous = channelId === ALL_SCENES_CHANNEL_ID;
  const source = continuous ? [...new Map((scenes || []).map((scene) => [scene.id, scene])).values()] : scenes;
  const pool = (source || []).filter((s) => durationMsOf(s) > 0);
  if (pool.length === 0) return { entries: [], totalMs: 0 };
  const ordered = seededShuffle(pool, hashString(`${channelId}|${continuous ? "continuous-v1" : dayKey}`));
  const entries = [];
  let offsetMs = 0;
  for (const scene of ordered) {
    const durationMs = durationMsOf(scene);
    entries.push({ scene, offsetMs, durationMs });
    offsetMs += durationMs;
  }
  return { entries, totalMs: offsetMs, ...continuous ? { epochMs: ALL_SCENES_EPOCH_MS } : {} };
}
function mod(n, m) {
  return (n % m + m) % m;
}
function indexAtCursor(entries, cursor) {
  let lo = 0;
  let hi = entries.length - 1;
  while (lo < hi) {
    const mid = lo + hi + 1 >> 1;
    if (entries[mid].offsetMs <= cursor) lo = mid;
    else hi = mid - 1;
  }
  return lo;
}
function programAt(daySchedule, nowMs, dayStartMs) {
  const { entries, totalMs } = daySchedule;
  if (totalMs <= 0) return null;
  dayStartMs = daySchedule.epochMs ?? dayStartMs;
  const sinceDayStart = nowMs - dayStartMs;
  const cursor = mod(sinceDayStart, totalMs);
  const loopBase = dayStartMs + Math.floor(sinceDayStart / totalMs) * totalMs;
  const index = indexAtCursor(entries, cursor);
  const entry = entries[index];
  const startMs = loopBase + entry.offsetMs;
  return {
    scene: entry.scene,
    index,
    startMs,
    endMs: startMs + entry.durationMs,
    elapsedMs: cursor - entry.offsetMs,
    durationMs: entry.durationMs
  };
}

// src/api/scenes.js
var SCENE_COUNT_QUERY = `query TVGuideSceneCount($filter: SceneFilterType) {
  findScenes(scene_filter: $filter) { count }
}`;
var SCENE_POOL_QUERY = `query TVGuideScenePool($filter: SceneFilterType, $find: FindFilterType) {
  findScenes(scene_filter: $filter, filter: $find) {
    scenes {
      id
      title
      details
      updated_at
      date
      paths { screenshot stream }
      files { duration }
      studio { name image_path }
      performers { id name image_path }
      tags { id name image_path }
    }
  }
}`;
async function fetchScenePool(gql, sceneFilter, poolCap, dayKey = dayBucket(Date.now()).key, channelId = JSON.stringify(sceneFilter)) {
  const result = await gql(SCENE_COUNT_QUERY, { filter: sceneFilter });
  const count = result?.findScenes?.count;
  if (!Number.isInteger(count) || count < 0) throw new Error("Unable to count channel scenes");
  if (!count) return [];
  const pages = Math.ceil(count / poolCap);
  const day = Math.floor(Date.parse(`${dayKey}T00:00:00Z`) / 864e5) || 0;
  const page = ((day + hashString(channelId)) % pages + pages) % pages + 1;
  const fetchPage = async (pageNumber, size) => {
    const data = await gql(SCENE_POOL_QUERY, {
      filter: sceneFilter,
      find: { per_page: size, page: pageNumber, sort: "id", direction: "ASC" }
    });
    if (!Array.isArray(data?.findScenes?.scenes)) throw new Error("Unable to load channel scenes");
    return data.findScenes.scenes;
  };
  const scenes = [...await fetchPage(page, poolCap)];
  if (count > poolCap && page > 1 && scenes.length < poolCap) {
    scenes.push(...await fetchPage(1, poolCap - scenes.length));
  }
  return [...new Map(scenes.map((scene) => [scene.id, scene])).values()];
}
var SCENE_INDEX_QUERY = `query TVGuideSceneIndex($filter: SceneFilterType, $find: FindFilterType) {
    findScenes(scene_filter: $filter, filter: $find) {
        scenes { id title updated_at files { duration } }
    }
}`;
async function fetchAllScenePool(gql) {
  const scenes = /* @__PURE__ */ new Map();
  const perPage = 500;
  for (let page = 1; ; page += 1) {
    const data = await gql(SCENE_INDEX_QUERY, {
      filter: {},
      find: { per_page: perPage, page, sort: "id", direction: "ASC" }
    });
    const batch = data?.findScenes?.scenes;
    if (!Array.isArray(batch)) throw new Error("Unable to load the full scene library");
    for (const scene of batch) scenes.set(scene.id, { ...scene, _summary: true });
    if (batch.length < perPage) return [...scenes.values()];
  }
}
async function fetchSceneDetails(gql, id) {
  const data = await gql(`query TVGuideSceneDetails($id: ID!) {
        findScene(id: $id) {
            id title details date updated_at files { duration }
            paths { screenshot stream }
            studio { name image_path }
            performers { id name image_path }
            tags { id name image_path }
        }
    }`, { id });
  if (!data?.findScene) throw new Error("Scene details are unavailable");
  return { ...data.findScene, _summary: false };
}

// src/domain/lineup.js
var KNOWN_SOURCES = ["special", "studio", "performer", "tag", "group", "savedFilter"];
var SOURCE_LABELS = {
  studio: "Studios",
  performer: "Models",
  tag: "Tags",
  group: "Groups",
  savedFilter: "Filters",
  special: "Special"
};
var DEFAULT_LINEUP = [
  { source: "special", minScenes: 0, ids: ["new-releases", "recently-added", "movies", "shorts"] },
  { source: "studio", minScenes: 5 }
];
function toStringList(value) {
  if (!Array.isArray(value)) return void 0;
  const out = value.map((v) => v == null ? "" : String(v)).filter(Boolean);
  return out.length > 0 ? out : void 0;
}
function toCount(value) {
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) && n > 0 ? n : 0;
}
function validateLineup(entries) {
  if (!Array.isArray(entries)) return [];
  return entries.reduce((out, entry) => {
    if (!entry || typeof entry !== "object") return out;
    if (!KNOWN_SOURCES.includes(entry.source)) return out;
    const normalised = { source: entry.source, minScenes: toCount(entry.minScenes) };
    const ids = toStringList(entry.ids);
    if (ids) normalised.ids = ids;
    const names = toStringList(entry.names);
    if (names) normalised.names = names;
    out.push(normalised);
    return out;
  }, []);
}
function parseLineup(json) {
  if (typeof json !== "string" || json === "") return DEFAULT_LINEUP;
  let parsed;
  try {
    parsed = JSON.parse(json);
  } catch (e) {
    return DEFAULT_LINEUP;
  }
  const valid = validateLineup(parsed);
  return valid.length > 0 ? valid : DEFAULT_LINEUP;
}
function makeChannelId(source, id) {
  return `${source}:${id}`;
}

// src/domain/channelPrefs.js
var DEFAULT_SORT = "name";
var isPlainObject = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
function validatePref(pref) {
  if (!isPlainObject(pref)) return null;
  const out = {};
  if (typeof pref.name === "string" && pref.name.trim()) out.name = pref.name.trim();
  if (typeof pref.logoUrl === "string" && pref.logoUrl.trim()) out.logoUrl = pref.logoUrl.trim();
  if (pref.hidden === true) out.hidden = true;
  const cap = Number.parseInt(pref.poolCap, 10);
  if (Number.isFinite(cap) && cap > 0) out.poolCap = cap;
  return Object.keys(out).length > 0 ? out : null;
}
function validatePrefs(prefs) {
  if (!isPlainObject(prefs)) return {};
  const out = {};
  for (const [channelId, pref] of Object.entries(prefs)) {
    const valid = validatePref(pref);
    if (valid) out[channelId] = valid;
  }
  return out;
}
function parsePrefs(json) {
  if (typeof json !== "string" || json === "") return {};
  try {
    return validatePrefs(JSON.parse(json));
  } catch (e) {
    return {};
  }
}
function validatePinOrder(value) {
  if (!Array.isArray(value)) return [];
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const id of value) {
    if (typeof id !== "string" || id === "" || seen.has(id)) continue;
    seen.add(id);
    out.push(id);
  }
  return out;
}
function parsePinOrder(json) {
  if (typeof json !== "string" || json === "") return [];
  try {
    return validatePinOrder(JSON.parse(json));
  } catch (e) {
    return [];
  }
}
function migratePinOrder(prefs) {
  return Object.entries(prefs || {}).filter(([, pref]) => pref && Number(pref.pinnedAt) > 0).sort((a, b) => Number(a[1].pinnedAt) - Number(b[1].pinnedAt)).map(([channelId]) => channelId);
}
function poolCapFor(prefs, channelId, defaultCap) {
  return prefs[channelId]?.poolCap || defaultCap;
}
function applyPrefs(channels, prefs) {
  const out = [];
  for (const channel of channels) {
    const pref = prefs[channel.id];
    if (pref?.hidden) continue;
    if (!pref || !pref.name && !pref.logoUrl) {
      out.push(channel);
      continue;
    }
    out.push({
      ...channel,
      name: pref.name || channel.name,
      logo: pref.logoUrl ? { type: "image", url: pref.logoUrl } : channel.logo
    });
  }
  return out;
}
var byName = (a, b) => a.name.localeCompare(b.name);
var COMPARATORS = {
  name: byName,
  // Most-stocked first; a saved filter has no count and sorts last.
  sceneCount: (a, b) => (b.sceneCount ?? -1) - (a.sceneCount ?? -1) || byName(a, b)
};
var PINNED_GROUP = "pinned";
function groupChannels(channels, { prefs = {}, pinOrder = [], sort = DEFAULT_SORT, sourceOrder = [], collapsed = [] } = {}) {
  const compare = COMPARATORS[sort] || COMPARATORS[DEFAULT_SORT];
  const visible = applyPrefs(channels, prefs);
  const byId = new Map(visible.map((c) => [c.id, c]));
  const groups = [];
  const pinned = pinOrder.map((id) => byId.get(id)).filter(Boolean);
  if (pinned.length > 0) {
    groups.push({
      key: PINNED_GROUP,
      source: null,
      channels: pinned,
      collapsed: collapsed.includes(PINNED_GROUP),
      count: pinned.length
    });
  }
  const pinnedIds = new Set(pinned.map((c) => c.id));
  const bySource = /* @__PURE__ */ new Map();
  for (const channel of visible) {
    if (pinnedIds.has(channel.id)) continue;
    if (!bySource.has(channel.source)) bySource.set(channel.source, []);
    bySource.get(channel.source).push(channel);
  }
  const ordered = [...sourceOrder, ...[...bySource.keys()].filter((s) => !sourceOrder.includes(s))];
  for (const source of ordered) {
    const list = bySource.get(source);
    if (!list || list.length === 0) continue;
    groups.push({
      key: source,
      source,
      channels: list.slice().sort(compare),
      collapsed: collapsed.includes(source),
      count: list.length
    });
  }
  return groups;
}

// src/domain/format.js
function monogram(name) {
  const clean = (name || "").trim();
  const words = clean.split(/\s+/).filter(Boolean);
  let initials;
  if (words.length === 0) initials = "?";
  else if (words.length === 1) initials = words[0].slice(0, 2);
  else initials = words[0][0] + words[1][0];
  let hue = 0;
  for (let i = 0; i < clean.length; i++) {
    hue = (hue * 31 + clean.charCodeAt(i)) % 360;
  }
  return { initials: initials.toUpperCase(), hue };
}

// src/domain/logo.js
function isDefaultImage(url) {
  if (typeof url !== "string" || url === "") return true;
  return /[?&]default=true(&|$)/.test(url);
}
function resolveLogo(url, name) {
  if (isDefaultImage(url)) {
    return { type: "monogram", ...monogram(name) };
  }
  return { type: "image", url };
}

// src/domain/providers/entityProvider.js
function createEntityProvider(config) {
  const {
    source,
    queryName,
    rootField,
    filterArg,
    filterType,
    collectionField,
    logoField,
    sceneFilterKey,
    favoriteFilterKey = null,
    supportsGender = false,
    // studios/tags/groups take a HierarchicalMultiCriterionInput, which
    // accepts `depth`. Performers take a plain MultiCriterionInput, which
    // does not -- sending depth there fails validation.
    hierarchical = true
  } = config;
  const gqlQuery = `query ${queryName}($f: ${filterType}, $find: FindFilterType, $ids: [ID!]) {
  ${rootField}(${filterArg}: $f, filter: $find, ids: $ids) {
    count
    ${collectionField} { id name ${logoField} scene_count }
  }
}`;
  const toChannel = (entity) => ({
    id: makeChannelId(source, entity.id),
    source,
    name: entity.name,
    logo: resolveLogo(entity[logoField], entity.name),
    sceneCount: entity.scene_count ?? 0,
    sceneFilter: {
      [sceneFilterKey]: hierarchical ? { value: [entity.id], modifier: "INCLUDES", depth: -1 } : { value: [entity.id], modifier: "INCLUDES" }
    }
  });
  return {
    source,
    query: gqlQuery,
    capabilities: { favorite: Boolean(favoriteFilterKey), gender: supportsGender },
    async listChannels(entry, gql) {
      const byIds = Array.isArray(entry.ids) && entry.ids.length > 0;
      const variables = {
        ids: byIds ? entry.ids : null,
        f: byIds ? null : countFilter(entry.minScenes),
        find: { per_page: -1, sort: "name", direction: "ASC" }
      };
      const data = await gql(gqlQuery, variables);
      const entities = data?.[rootField]?.[collectionField] || [];
      return entities.map(toChannel);
    },
    async listCatalogPage({ page = 1, perPage = 50, query: search = "", favorited = false, gender = "all", sort = "name" }, gql) {
      const f = {};
      if (favorited && favoriteFilterKey) f[favoriteFilterKey] = true;
      if (supportsGender && gender !== "all") {
        f.gender = { value: gender.toUpperCase(), modifier: "EQUALS" };
      }
      const data = await gql(gqlQuery, {
        f: Object.keys(f).length > 0 ? f : null,
        find: {
          page,
          per_page: perPage,
          ...search ? { q: search } : {},
          sort: sort === "sceneCount" ? "scenes_count" : "name",
          direction: sort === "sceneCount" ? "DESC" : "ASC"
        }
      });
      const result = data?.[rootField] || {};
      return {
        channels: (result[collectionField] || []).map(toChannel),
        total: result.count || 0
      };
    }
  };
}
function countFilter(minScenes) {
  if (!minScenes || minScenes <= 0) return null;
  return { scene_count: { value: minScenes - 1, modifier: "GREATER_THAN" } };
}

// src/domain/providers/studio.js
var studio_default = createEntityProvider({
  source: "studio",
  queryName: "TVGuideStudios",
  rootField: "findStudios",
  filterArg: "studio_filter",
  filterType: "StudioFilterType",
  collectionField: "studios",
  logoField: "image_path",
  sceneFilterKey: "studios",
  favoriteFilterKey: "favorite"
});

// src/domain/providers/tag.js
var tag_default = createEntityProvider({
  source: "tag",
  queryName: "TVGuideTags",
  rootField: "findTags",
  filterArg: "tag_filter",
  filterType: "TagFilterType",
  collectionField: "tags",
  logoField: "image_path",
  sceneFilterKey: "tags",
  favoriteFilterKey: "favorite"
});

// src/domain/providers/group.js
var group_default = createEntityProvider({
  source: "group",
  queryName: "TVGuideGroups",
  rootField: "findGroups",
  filterArg: "group_filter",
  filterType: "GroupFilterType",
  collectionField: "groups",
  logoField: "front_image_path",
  sceneFilterKey: "groups"
});

// src/domain/providers/performer.js
var performer_default = createEntityProvider({
  source: "performer",
  queryName: "TVGuidePerformers",
  rootField: "findPerformers",
  filterArg: "performer_filter",
  filterType: "PerformerFilterType",
  collectionField: "performers",
  logoField: "image_path",
  sceneFilterKey: "performers",
  favoriteFilterKey: "filter_favorites",
  supportsGender: true,
  hierarchical: false
});

// src/domain/savedFilterCriteria.js
var NESTED_FIELDS = ["AND", "OR", "NOT"];
var idsOf = (list) => (Array.isArray(list) ? list : []).map((item) => item && typeof item === "object" ? item.id : item).filter((id) => id != null).map(String);
function isMultiCriterion(criterion) {
  return criterion && typeof criterion === "object" && criterion.value && typeof criterion.value === "object" && !Array.isArray(criterion.value);
}
function convertCriterion(criterion) {
  const { items, excluded, depth } = criterion.value;
  const converted = { modifier: criterion.modifier, value: idsOf(items) };
  const excludes = idsOf(excluded);
  if (excludes.length > 0) converted.excludes = excludes;
  if (depth) converted.depth = depth;
  return converted;
}
function savedFilterToSceneFilter(objectFilter) {
  if (!objectFilter || typeof objectFilter !== "object") return {};
  const out = {};
  for (const [field, criterion] of Object.entries(objectFilter)) {
    if (NESTED_FIELDS.includes(field)) {
      out[field] = Array.isArray(criterion) ? criterion.map(savedFilterToSceneFilter) : savedFilterToSceneFilter(criterion);
      continue;
    }
    out[field] = isMultiCriterion(criterion) ? convertCriterion(criterion) : criterion;
  }
  return out;
}

// src/domain/providers/savedFilter.js
var QUERY = `query TVGuideSavedFilters {
  findSavedFilters(mode: SCENES) {
    id
    name
    object_filter
    find_filter { sort direction }
  }
}`;
var savedFilter_default = {
  source: "savedFilter",
  query: QUERY,
  capabilities: { favorite: false, gender: false },
  async listChannels(entry, gql) {
    const data = await gql(QUERY);
    const filters = data?.findSavedFilters || [];
    const wanted = Array.isArray(entry.names) && entry.names.length > 0 ? new Set(entry.names) : null;
    return filters.filter((f) => !wanted || wanted.has(f.name)).filter((f) => f.object_filter && Object.keys(f.object_filter).length > 0).map((f) => ({
      id: makeChannelId("savedFilter", f.id),
      source: "savedFilter",
      name: f.name,
      logo: resolveLogo(null, f.name),
      sceneCount: null,
      // not knowable without running the filter
      sceneFilter: savedFilterToSceneFilter(f.object_filter)
    }));
  },
  async listCatalogPage({ page = 1, perPage = 50, query = "" }, gql) {
    const channels = await this.listChannels({ source: "savedFilter" }, gql);
    const normalized = query.trim().toLowerCase();
    const filtered = normalized ? channels.filter((channel) => channel.name.toLowerCase().includes(normalized)) : channels;
    const start = (page - 1) * perPage;
    return { channels: filtered.slice(start, start + perPage), total: filtered.length };
  }
};

// src/domain/providers/special.js
var SPECIALS = [
  {
    id: "all-scenes",
    name: "All Scenes",
    filter: () => ({})
  },
  {
    id: "new-releases",
    name: "New releases",
    filter: (settings, now) => ({
      date: { value: dateDaysAgo(now, settings.guide_new_release_days), modifier: "GREATER_THAN" }
    })
  },
  {
    id: "recently-added",
    name: "Recently added",
    filter: (settings, now) => ({
      created_at: { value: instantDaysAgo(now, settings.guide_recently_added_days), modifier: "GREATER_THAN" }
    })
  },
  {
    id: "movies",
    name: "Movies",
    filter: (settings) => ({
      duration: { value: settings.guide_movie_min_minutes * 60, modifier: "GREATER_THAN" }
    })
  },
  {
    id: "shorts",
    name: "Shorts",
    filter: (settings) => ({
      duration: { value: settings.guide_short_max_minutes * 60, modifier: "LESS_THAN" }
    })
  }
];
var DEFAULT_SPECIAL_SETTINGS = {
  guide_new_release_days: 30,
  guide_recently_added_days: 14,
  guide_movie_min_minutes: 90,
  guide_short_max_minutes: 5
};
var allSpecials = (settings, now) => {
  const config = { ...DEFAULT_SPECIAL_SETTINGS, ...settings && typeof settings === "object" ? settings : {} };
  return SPECIALS.map((special) => ({
    id: makeChannelId("special", special.id),
    source: "special",
    name: special.name,
    logo: resolveLogo(null, special.name),
    sceneCount: null,
    sceneFilter: special.filter(config, now)
  }));
};
function dateDaysAgo(now, days) {
  const date = new Date(now);
  date.setUTCDate(date.getUTCDate() - days);
  return date.toISOString().slice(0, 10);
}
function instantDaysAgo(now, days) {
  return new Date(now.getTime() - days * 24 * 60 * 60 * 1e3).toISOString();
}
var special_default = {
  source: "special",
  capabilities: { favorite: false, gender: false },
  async listChannels(entry, _gql, settings, now = /* @__PURE__ */ new Date()) {
    const channels = allSpecials(settings, now);
    if (!Array.isArray(entry.ids) || entry.ids.length === 0) return channels;
    const selected = new Set(entry.ids);
    return channels.filter((channel) => selected.has(channel.id.slice("special:".length)));
  },
  async listCatalogPage({ page = 1, perPage = 50, query = "" }, _gql, settings, now = /* @__PURE__ */ new Date()) {
    const normalized = query.trim().toLowerCase();
    const filtered = normalized ? allSpecials(settings, now).filter((channel) => channel.name.toLowerCase().includes(normalized)) : allSpecials(settings, now);
    const start = (page - 1) * perPage;
    return { channels: filtered.slice(start, start + perPage), total: filtered.length };
  }
};

// src/domain/providers/index.js
var PROVIDERS = {
  [studio_default.source]: studio_default,
  [tag_default.source]: tag_default,
  [group_default.source]: group_default,
  [performer_default.source]: performer_default,
  [savedFilter_default.source]: savedFilter_default,
  [special_default.source]: special_default
};
async function resolveLineup(lineup, gql, settings, now) {
  const results = await Promise.all(
    lineup.map(async (entry) => {
      const provider = PROVIDERS[entry.source];
      if (!provider) return { channels: [], error: null };
      try {
        return { channels: await provider.listChannels(entry, gql, settings, now), error: null };
      } catch (e) {
        return { channels: [], error: { source: entry.source, message: e.message } };
      }
    })
  );
  const channels = [];
  const errors = [];
  const seen = /* @__PURE__ */ new Set();
  for (const result of results) {
    if (result.error) errors.push(result.error);
    for (const channel of result.channels) {
      if (seen.has(channel.id)) continue;
      seen.add(channel.id);
      channels.push(channel);
    }
  }
  return { channels, errors };
}

// iptv/guide.js
function nextMidnight(ms) {
  const date = new Date(ms);
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1).getTime();
}
async function loadGuide(gql) {
  const data = await gql("query TVGuideIPTVConfiguration { configuration { plugins } }");
  if (!data.configuration?.plugins) throw new Error("Stash plugin configuration is unavailable");
  const config = data.configuration.plugins.TVGuide || {};
  const state = config.tvguide_state || {};
  const settings = normalizeSettings(config);
  const lineup = state.tvguide_lineup == null ? [
    { source: "special", minScenes: 0, ids: ["new-releases", "recently-added", "movies", "shorts"] },
    { source: "studio", minScenes: settings.guide_min_scenes }
  ] : parseLineup(state.tvguide_lineup);
  const { channels, errors } = await resolveLineup(lineup, gql, settings);
  if (errors.length) throw new Error("Unable to resolve the complete TVGuide lineup");
  const prefs = parsePrefs(state.tvguide_channel_prefs);
  let legacy = {};
  try {
    legacy = JSON.parse(state.tvguide_channel_prefs || "{}");
  } catch {
  }
  const pinOrder = state.tvguide_pin_order == null ? migratePinOrder(legacy) : parsePinOrder(state.tvguide_pin_order);
  const ordered = groupChannels(channels, { prefs, pinOrder, sourceOrder: KNOWN_SOURCES }).flatMap((g) => g.channels);
  const plans = /* @__PURE__ */ new Map();
  let allScenes;
  async function getPlan(channel, ms) {
    const day = dayBucket(ms);
    const key = `${channel.id}|${day.key}`;
    if (!plans.has(key)) {
      const pending = (async () => {
        let scenes;
        if (channel.id === ALL_SCENES_CHANNEL_ID) {
          allScenes ||= fetchAllScenePool(gql).catch((error) => {
            allScenes = null;
            throw error;
          });
          scenes = await allScenes;
        } else {
          let filter = channel.sceneFilter;
          if (channel.source === "special") {
            const [daily] = await special_default.listChannels({ ids: [channel.id.slice(8)] }, gql, settings, new Date(day.startMs));
            filter = daily.sceneFilter;
          }
          scenes = await fetchScenePool(gql, filter, poolCapFor(prefs, channel.id, settings.guide_pool_cap), day.key, channel.id);
        }
        return buildDaySchedule(channel.id, scenes, day.key);
      })();
      plans.set(key, pending);
      pending.catch(() => plans.delete(key));
      for (const old of plans.keys()) if (old !== key && old.slice(old.lastIndexOf("|") + 1) < dayBucket(ms - 8 * 864e5).key) plans.delete(old);
    }
    return plans.get(key);
  }
  return {
    channels: ordered,
    getPlan,
    async program(channel, ms) {
      const day = dayBucket(ms);
      const current = programAt(await getPlan(channel, ms), ms, day.startMs);
      if (!current) return null;
      const endMs = channel.id === ALL_SCENES_CHANNEL_ID ? current.endMs : Math.min(current.endMs, nextMidnight(ms));
      return { ...current, endMs };
    }
  };
}
function xml(value) {
  return String(value ?? "").replace(/[^\u0009\u000a\u000d\u0020-\ud7ff\ue000-\ufffd\u{10000}-\u{10ffff}]/gu, "").replace(/[<>&"']/g, (c) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", '"': "&quot;", "'": "&apos;" })[c]);
}
function xmlTime(ms) {
  return new Date(ms).toISOString().replace(/[-:T]/g, "").slice(0, 14) + " +0000";
}
function m3uText(value) {
  return String(value ?? "").replace(/[\x00-\x1f\x7f"<>]/g, " ");
}
function logoUrl(channel, config) {
  if (channel.logo?.type !== "image") return null;
  try {
    const url = new URL(channel.logo.url, `${config.stashUrl}/`);
    if (url.origin === new URL(config.stashUrl).origin) return endpoint(config, `/logo/${encodeURIComponent(channel.id)}`);
    return ["http:", "https:"].includes(url.protocol) ? url.href : null;
  } catch {
    return null;
  }
}
function renderM3u(channels, config) {
  const lines = [`#EXTM3U x-tvg-url="${endpoint(config, "/epg.xml")}"`];
  for (const channel of channels) {
    const logo = logoUrl(channel, config);
    lines.push(`#EXTINF:-1 tvg-id="${m3uText(channel.id)}" tvg-name="${m3uText(channel.name)}"${logo ? ` tvg-logo="${m3uText(logo)}"` : ""} group-title="${m3uText(SOURCE_LABELS[channel.source] || "TVGuide")}",${m3uText(channel.name)}`);
    lines.push(endpoint(config, `/stream/${encodeURIComponent(channel.id)}.ts`));
  }
  return lines.join("\n") + "\n";
}
async function renderXmltv(guide, channels, config, fromMs, toMs) {
  const lines = ['<?xml version="1.0" encoding="UTF-8"?>', '<tv generator-info-name="Stash TVGuide">'];
  for (const channel of channels) {
    const logo = logoUrl(channel, config);
    lines.push(`<channel id="${xml(channel.id)}"><display-name>${xml(channel.name)}</display-name>${logo ? `<icon src="${xml(logo)}"/>` : ""}</channel>`);
  }
  for (const channel of channels) {
    let cursor = fromMs;
    let count = 0;
    while (cursor < toMs) {
      if (++count > 1e5) throw new Error("Too many programmes for XMLTV; reduce TVGUIDE_EPG_DAYS");
      const program = await guide.program(channel, cursor);
      if (!program) {
        cursor = nextMidnight(cursor);
        continue;
      }
      const { scene, startMs, endMs } = program;
      const start = Math.max(startMs, dayBucket(cursor).startMs, fromMs);
      const end = Math.min(endMs, toMs);
      if (endMs <= cursor) throw new Error("Invalid programme boundary");
      if (Math.floor(end / 1e3) > Math.floor(start / 1e3)) {
        const title = scene.title?.trim() || `Untitled scene ${scene.id}`;
        lines.push(`<programme channel="${xml(channel.id)}" start="${xmlTime(start)}" stop="${xmlTime(end)}"><title>${xml(title)}</title>${scene.details ? `<desc>${xml(scene.details)}</desc>` : ""}</programme>`);
      }
      cursor = endMs;
    }
  }
  lines.push("</tv>");
  return lines.join("\n") + "\n";
}
async function playableChannels(guide, nowMs) {
  const out = [];
  for (let i = 0; i < guide.channels.length; i += 4) {
    const batch = guide.channels.slice(i, i + 4);
    const plans = await Promise.all(batch.map((channel) => guide.getPlan(channel, nowMs)));
    batch.forEach((channel, index) => {
      if (plans[index].totalMs > 0) out.push(channel);
    });
  }
  return out;
}

// iptv/stream.js
var import_node_child_process = require("node:child_process");
var import_promises = require("node:timers/promises");

// iptv/mediaProxy.js
var import_node_http = require("node:http");
var import_node_crypto = require("node:crypto");
var import_node_events = require("node:events");
var import_node_stream = require("node:stream");
async function createMediaProxy(config, upstreamUrl, fetchFn = fetch) {
  const path = `/${(0, import_node_crypto.randomUUID)()}/media`;
  const server = (0, import_node_http.createServer)(async (request, response) => {
    if (request.url !== path || !["GET", "HEAD"].includes(request.method)) {
      response.writeHead(404).end();
      return;
    }
    const controller = new AbortController();
    const headerTimer = setTimeout(() => controller.abort(), 3e4);
    response.once("close", () => controller.abort());
    try {
      const upstream = await fetchFn(upstreamUrl, {
        method: request.method,
        headers: { ...stashHeaders(config), ...request.headers.range ? { Range: request.headers.range } : {} },
        redirect: "error",
        signal: controller.signal
      });
      clearTimeout(headerTimer);
      if (![200, 206, 416].includes(upstream.status)) throw new Error("Media unavailable");
      const headers = {};
      for (const name of ["content-type", "content-length", "content-range", "accept-ranges"]) {
        const value = upstream.headers.get(name);
        if (value) headers[name] = value;
      }
      response.writeHead(upstream.status, headers);
      if (request.method === "HEAD" || !upstream.body) response.end();
      else {
        const body = import_node_stream.Readable.fromWeb(upstream.body);
        body.on("error", () => response.destroy());
        body.pipe(response);
      }
    } catch {
      if (response.headersSent) response.destroy();
      else response.writeHead(502).end();
    } finally {
      clearTimeout(headerTimer);
    }
  });
  server.listen(0, "127.0.0.1");
  await (0, import_node_events.once)(server, "listening");
  return { url: `http://127.0.0.1:${server.address().port}${path}`, close() {
    server.close();
    server.closeAllConnections();
  } };
}

// iptv/stream.js
function ffmpegArgs(config, url, offsetSeconds, durationSeconds, timestampSeconds, version) {
  return [
    "-hide_banner",
    "-loglevel",
    "error",
    "-nostdin",
    "-rw_timeout",
    "15000000",
    "-re",
    "-ss",
    offsetSeconds.toFixed(3),
    "-i",
    url,
    "-t",
    durationSeconds.toFixed(3),
    "-map",
    "0:v:0",
    "-map",
    "0:a:0?",
    "-vf",
    "scale=1280:720:force_original_aspect_ratio=decrease:force_divisible_by=2,pad=1280:720:(ow-iw)/2:(oh-ih)/2,setsar=1",
    "-r",
    "25",
    "-c:v",
    "libx264",
    "-preset",
    "veryfast",
    "-tune",
    "zerolatency",
    "-crf",
    "23",
    "-pix_fmt",
    "yuv420p",
    "-g",
    "50",
    "-bf",
    "0",
    "-c:a",
    "aac",
    "-b:a",
    "128k",
    "-ar",
    "48000",
    "-ac",
    "2",
    "-af",
    "aresample=async=1:first_pts=0",
    "-mpegts_flags",
    "+resend_headers+initial_discontinuity",
    "-tables_version",
    String(version % 32),
    "-output_ts_offset",
    timestampSeconds.toFixed(3),
    "-muxdelay",
    "0",
    "-muxpreload",
    "0",
    "-f",
    "mpegts",
    "pipe:1"
  ];
}
function sendProgramme({ response, config, args, durationMs, spawnFn = import_node_child_process.spawn }) {
  return new Promise((resolve, reject) => {
    const child = spawnFn(config.ffmpeg, args, { stdio: ["ignore", "pipe", "pipe"], windowsHide: true });
    let received = false;
    let failed = false;
    const timer = setTimeout(() => {
      failed = true;
      child.kill("SIGKILL");
    }, durationMs + 1e4);
    const cancel = () => child.kill("SIGKILL");
    response.once("close", cancel);
    child.stderr.resume();
    child.stdout.once("data", () => {
      received = true;
      if (!response.headersSent) response.writeHead(200, { "Content-Type": "video/mp2t", "Cache-Control": "no-store" });
    });
    child.stdout.pipe(response, { end: false });
    const cleanup = () => {
      clearTimeout(timer);
      response.off("close", cancel);
      child.stdout.unpipe(response);
    };
    child.once("error", () => {
      cleanup();
      reject(new Error("Unable to start FFmpeg"));
    });
    child.once("close", (code) => {
      cleanup();
      if (response.destroyed) resolve(false);
      else if (failed || code !== 0 || !received) reject(new Error("FFmpeg could not play the scheduled scene"));
      else resolve(true);
    });
    if (response.destroyed) cancel();
  });
}
async function streamChannel({ response, config, channelId, getGuide, gql, now = Date.now, send = sendProgramme, proxy = createMediaProxy }) {
  const epoch = now();
  let version = 0;
  while (!response.destroyed) {
    const guide = await getGuide();
    const channel = guide.channels.find((c) => c.id === channelId);
    if (!channel) throw new Error("Channel is no longer available");
    let current = await guide.program(channel, now());
    if (!current) throw new Error("Channel has no playable scenes");
    const scene = current.scene._summary || !current.scene.paths?.stream ? await fetchSceneDetails(gql, current.scene.id) : current.scene;
    if (response.destroyed) break;
    const start = now();
    if (start >= current.endMs) continue;
    const url = stashMediaUrl(config, scene.paths.stream);
    const durationMs = current.endMs - start;
    const relay = await proxy(config, url);
    let complete;
    try {
      const args = ffmpegArgs(config, relay.url, (start - current.startMs) / 1e3, durationMs / 1e3, (start - epoch) / 1e3, version++);
      complete = await send({ response, config, args, durationMs });
    } finally {
      relay.close();
    }
    if (!complete || response.destroyed) break;
    const waitMs = current.endMs - now();
    if (waitMs > 2e3) throw new Error("Scheduled scene ended before its declared duration");
    if (waitMs > 0) {
      const abort = new AbortController();
      const cancel = () => abort.abort();
      response.once("close", cancel);
      try {
        await (0, import_promises.setTimeout)(waitMs, void 0, { signal: abort.signal });
      } catch (error) {
        if (error.name !== "AbortError") throw error;
      } finally {
        response.off("close", cancel);
      }
    }
  }
}

// iptv/server.js
function authorized(request, url, token) {
  const supplied = request.headers.authorization?.replace(/^Bearer /, "") || url.searchParams.get("token") || "";
  const a = Buffer.from(supplied);
  const b = Buffer.from(token);
  return a.length === b.length && (0, import_node_crypto2.timingSafeEqual)(a, b);
}
function createIptvServer(config, { gql = createStashClient(config), load = loadGuide, stream = streamChannel, fetchFn = fetch, now = Date.now, log = console.error } = {}) {
  let snapshot;
  let expires = 0;
  let active = 0;
  let epg;
  const prefix = new URL(config.publicUrl).pathname.replace(/\/$/, "");
  const getGuide = async () => {
    if (!snapshot || now() >= expires) {
      expires = Math.min(now() + 3e5, nextMidnight(now()));
      const pending = load(gql);
      snapshot = pending;
      epg = null;
      pending.catch(() => {
        if (snapshot === pending) snapshot = null;
      });
    }
    return snapshot;
  };
  const server = (0, import_node_http2.createServer)(async (request, response) => {
    const reply = (status, text, type = "text/plain; charset=utf-8") => {
      if (response.destroyed) return;
      response.writeHead(status, { "Content-Type": type, "Cache-Control": "no-store" });
      response.end(request.method === "HEAD" ? void 0 : text);
    };
    try {
      const url = new URL(request.url, "http://tvguide.invalid");
      if (config.controlToken && ["/control/status", "/control/stop"].includes(url.pathname)) {
        const supplied = Buffer.from(request.headers["x-tvguide-control"] || "");
        const expected = Buffer.from(config.controlToken);
        if (supplied.length !== expected.length || !(0, import_node_crypto2.timingSafeEqual)(supplied, expected)) return reply(401, "Unauthorized\n");
        if (url.pathname.endsWith("/status") && request.method === "GET") return reply(200, JSON.stringify({
          instanceId: config.instanceId,
          pid: process.pid,
          playlist: endpoint(config, "/playlist.m3u"),
          epg: endpoint(config, "/epg.xml")
        }), "application/json");
        if (url.pathname.endsWith("/stop") && request.method === "POST") {
          reply(200, JSON.stringify({ instanceId: config.instanceId }), "application/json");
          setImmediate(() => {
            server.close();
            server.closeAllConnections();
          });
          return;
        }
        return reply(405, "Method not allowed\n");
      }
      if (!authorized(request, url, config.token)) return reply(401, "Unauthorized\n");
      if (!["GET", "HEAD"].includes(request.method)) return reply(405, "GET or HEAD required\n");
      if (prefix && !url.pathname.startsWith(`${prefix}/`)) return reply(404, "Not found\n");
      const path = url.pathname.slice(prefix.length);
      if (path === "/health") return reply(200, "TVGuide IPTV is running\n");
      if (!["/playlist.m3u", "/epg.xml"].includes(path) && !/^\/(stream|logo)\/[^/]+$/.test(path)) return reply(404, "Not found\n");
      const guide = await getGuide();
      if (path === "/playlist.m3u" || path === "/epg.xml") {
        const channels = await playableChannels(guide, now());
        if (path === "/playlist.m3u") return reply(200, renderM3u(channels, config), "audio/x-mpegurl; charset=utf-8");
        if (!epg || epg.guide !== guide) {
          const from = dayBucket(now()).startMs;
          let to = from;
          for (let i = 0; i < config.days; i++) to = nextMidnight(to);
          const pending = renderXmltv(guide, channels, config, from, to);
          const entry = { guide, pending };
          epg = entry;
          pending.catch(() => {
            if (epg === entry) epg = null;
          });
        }
        return reply(200, await epg.pending, "application/xml; charset=utf-8");
      }
      const isStream = path.startsWith("/stream/");
      if (isStream && !path.endsWith(".ts")) return reply(404, "Not found\n");
      const id = decodeURIComponent(path.slice(isStream ? 8 : 6, isStream ? -3 : void 0));
      const channel = guide.channels.find((c) => c.id === id);
      if (!channel) return reply(404, "Unknown channel\n");
      if (!isStream) {
        if (channel.logo?.type !== "image") return reply(404, "No logo\n");
        const upstream = await fetchFn(stashMediaUrl(config, channel.logo.url), {
          headers: stashHeaders(config),
          signal: AbortSignal.timeout(15e3),
          redirect: "error"
        });
        const type = upstream.headers.get("content-type") || "";
        if (!upstream.ok || !/^image\/(png|jpeg|webp|gif)(;|$)/i.test(type)) return reply(502, "Logo unavailable\n");
        const chunks = [];
        let size = 0;
        for await (const chunk of upstream.body) {
          size += chunk.length;
          if (size > 5 * 1024 * 1024) throw new Error("Logo exceeds limit");
          chunks.push(chunk);
        }
        return reply(200, Buffer.concat(chunks), type);
      }
      if (!await guide.program(channel, now())) return reply(404, "Channel has no playable scenes\n");
      if (request.method === "HEAD") return reply(200, "", "video/mp2t");
      if (active >= config.maxStreams) return reply(503, "Simultaneous stream limit reached\n");
      active++;
      try {
        await stream({ response, config, channelId: id, getGuide, gql, now });
      } finally {
        active--;
      }
      if (!response.destroyed) response.end();
    } catch (error) {
      log(error instanceof StashRequestError ? `TVGuide IPTV: ${error.message}` : "TVGuide IPTV: request failed; check Stash connectivity, media URLs and FFmpeg.");
      if (response.headersSent) response.destroy();
      else reply(error instanceof URIError ? 400 : 502, "TVGuide upstream unavailable\n");
    }
  });
  return { server, getGuide, close() {
    server.close();
    server.closeAllConnections();
  } };
}

// iptv/pluginTask.js
var import_node_child_process2 = require("node:child_process");
var import_node_crypto3 = require("node:crypto");
var import_promises2 = require("node:fs/promises");
var import_node_path = require("node:path");
var import_promises3 = require("node:timers/promises");
function optionalNumber(value) {
  return value == null || typeof value === "string" && !value.trim() || Number(value) === 0 ? void 0 : value;
}
async function readInput(input = process.stdin) {
  let text = "";
  for await (const chunk of input) {
    text += chunk;
    if (text.length > 2 * 1024 * 1024) throw new Error("Plugin input exceeds limit");
  }
  return JSON.parse(text);
}
async function pluginConfig(input, { client = createStashClient } = {}) {
  const conn = input.server_connection || {};
  const cookie = conn.SessionCookie;
  const sessionCookie = cookie?.Name && cookie?.Value ? `${cookie.Name}=${cookie.Value}` : "";
  const localUrl = `${conn.Scheme || "http"}://127.0.0.1:${conn.Port || 9999}`;
  const bootstrap = { stashUrl: localUrl, apiKey: conn.ApiKey || "", sessionCookie };
  const data = await client(bootstrap)("query TVGuideIPTVTaskConfiguration { configuration { plugins general { ffmpegPath } } }");
  const stored = data?.configuration?.plugins?.TVGuide;
  if (!stored || typeof stored !== "object") throw new Error("TVGuide settings are unavailable in Stash");
  const config = readConfig({
    STASH_URL: stored.iptv_01_stash_url || localUrl,
    STASH_API_KEY: stored.iptv_02_api_key || conn.ApiKey || "",
    STASH_SESSION_COOKIE: sessionCookie,
    TVGUIDE_PUBLIC_URL: stored.iptv_03_public_url,
    TVGUIDE_TOKEN: stored.iptv_04_token,
    TVGUIDE_HOST: stored.iptv_05_host || "0.0.0.0",
    TVGUIDE_PORT: optionalNumber(stored.iptv_06_port),
    TVGUIDE_EPG_DAYS: optionalNumber(stored.iptv_07_epg_days),
    TVGUIDE_MAX_STREAMS: optionalNumber(stored.iptv_08_max_streams),
    FFMPEG_PATH: stored.iptv_10_ffmpeg || data.configuration.general?.ffmpegPath || "ffmpeg"
  });
  if (!stored.iptv_03_public_url) throw new Error("Set IPTV Public URL in TVGuide plugin settings to the Stash LXC address on port 9898");
  const timezone = stored.iptv_09_timezone || process.env.TZ || Intl.DateTimeFormat().resolvedOptions().timeZone;
  try {
    new Intl.DateTimeFormat("en", { timeZone: timezone });
  } catch {
    throw new Error("Invalid IPTV timezone");
  }
  return { ...config, timezone };
}
async function readState(file) {
  try {
    return JSON.parse(await (0, import_promises2.readFile)(file, "utf8"));
  } catch (error) {
    if (error.code === "ENOENT" || error instanceof SyntaxError) return null;
    throw error;
  }
}
async function control(state, action = "status") {
  if (!state) return null;
  const base = new URL(state.controlUrl);
  if (base.protocol !== "http:" || base.pathname !== "/" || base.search || base.username || base.password) throw new Error("Invalid IPTV control state");
  try {
    const response = await fetch(new URL(`/control/${action}`, base), {
      method: action === "stop" ? "POST" : "GET",
      headers: { "X-TVGuide-Control": state.controlToken },
      signal: AbortSignal.timeout(1500),
      redirect: "error"
    });
    if (!response.ok) return null;
    const result = await response.json();
    return result.instanceId === state.instanceId ? result : null;
  } catch {
    return null;
  }
}
async function runPluginTask(input, { script = process.argv[1], configure = pluginConfig, spawnFn = import_node_child_process2.spawn, checkBinary = (binary) => (0, import_node_child_process2.spawnSync)(binary, ["-version"], { windowsHide: true, timeout: 1e4, stdio: "ignore" }).status === 0 } = {}) {
  const operation = input.args?.operation;
  if (!["start", "stop", "restart", "status"].includes(operation)) throw new Error("Unknown IPTV plugin task");
  const root = input.server_connection?.Dir;
  if (!root) throw new Error("Stash did not provide its configuration directory");
  const dir = (0, import_node_path.join)(root, "tvguide-iptv");
  await (0, import_promises2.mkdir)(dir, { recursive: true, mode: 448 });
  const file = (0, import_node_path.join)(dir, "server.json");
  const lockFile = (0, import_node_path.join)(dir, "task.lock");
  let lock;
  try {
    lock = await (0, import_promises2.open)(lockFile, "wx", 384);
  } catch (error) {
    if (error.code !== "EEXIST") throw error;
    if (Date.now() - (await (0, import_promises2.stat)(lockFile)).mtimeMs < 12e4) throw new Error("Another IPTV task is running; retry shortly");
    await (0, import_promises2.unlink)(lockFile);
    lock = await (0, import_promises2.open)(lockFile, "wx", 384);
  }
  try {
    const previous = await readState(file);
    const running = await control(previous);
    if (operation === "status") return { running: Boolean(running), ...running, message: running ? "TVGuide IPTV is running." : "TVGuide IPTV is stopped." };
    if (operation === "start" && running) return { running: true, ...running, message: "TVGuide IPTV is already running. Use Restart IPTV Server after changing settings." };
    const config = operation === "stop" ? null : await configure(input);
    if (config && !checkBinary(config.ffmpeg)) throw new Error("FFmpeg is unavailable. Install ffmpeg or set IPTV FFmpeg Path.");
    if (running) {
      if (!await control(previous, "stop")) throw new Error("Unable to stop the IPTV instance");
      for (let i = 0; i < 30 && await control(previous); i++) await (0, import_promises3.setTimeout)(100);
      if (await control(previous)) throw new Error("IPTV server is still shutting down; retry shortly");
    }
    await (0, import_promises2.unlink)(file).catch((error) => {
      if (error.code !== "ENOENT") throw error;
    });
    if (operation === "stop") return { running: false, message: "TVGuide IPTV is stopped." };
    const host = ["0.0.0.0", "::"].includes(config.host) ? "127.0.0.1" : config.host;
    const state = {
      controlUrl: `http://${host.includes(":") ? `[${host}]` : host}:${config.port}`,
      controlToken: (0, import_node_crypto3.randomBytes)(32).toString("hex"),
      instanceId: (0, import_node_crypto3.randomUUID)()
    };
    await (0, import_promises2.writeFile)(file, JSON.stringify(state), { mode: 384, flag: "wx" });
    const child = spawnFn(process.execPath, [script, "--plugin-server"], {
      detached: true,
      windowsHide: true,
      stdio: ["pipe", "ignore", "ignore"],
      env: { ...process.env, TZ: config.timezone }
    });
    let failed = false;
    child.once("error", () => {
      failed = true;
    });
    child.once("exit", () => {
      failed = true;
    });
    child.stdin.on("error", () => {
      failed = true;
    });
    child.stdin.end(JSON.stringify({ ...config, ...state }));
    child.unref();
    const deadline = Date.now() + 45e3;
    while (!failed && Date.now() < deadline) {
      const ready = await control(state);
      if (ready) return { running: true, ...ready, message: "TVGuide IPTV started. The Stash task is complete; the server runs in the background." };
      await (0, import_promises3.setTimeout)(100);
    }
    child.kill();
    await (0, import_promises2.unlink)(file).catch(() => {
    });
    throw new Error("IPTV startup failed. Check Node.js 20+, Stash credentials, Public URL and whether the port is free.");
  } finally {
    await lock.close();
    await (0, import_promises2.unlink)(lockFile).catch(() => {
    });
  }
}

// iptv/index.js
if (require.main === module) {
  (async () => {
    if (process.argv.includes("--plugin-task")) {
      const result = await runPluginTask(await readInput());
      console.error(result.message);
      process.stdout.write(JSON.stringify({ output: result }));
      return;
    }
    const config = process.argv.includes("--plugin-server") ? await readInput() : readConfig();
    const app = createIptvServer(config);
    if (process.argv.includes("--plugin-server")) await app.getGuide();
    app.server.on("error", () => {
      console.error("TVGuide IPTV: unable to listen");
      process.exitCode = 1;
    });
    app.server.listen(config.port, config.host, () => console.log(`TVGuide IPTV listening on ${config.host}:${config.port}`));
    process.on("SIGINT", () => app.close());
    process.on("SIGTERM", () => app.close());
  })().catch((error) => {
    const message = process.argv.includes("--plugin-task") ? error.message : "TVGuide IPTV could not start; check settings and Stash connectivity.";
    if (process.argv.includes("--plugin-task")) process.stdout.write(JSON.stringify({ error: message }));
    console.error(message);
    process.exitCode = 1;
  });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  StashRequestError,
  createIptvServer,
  createMediaProxy,
  createStashClient,
  endpoint,
  ffmpegArgs,
  loadGuide,
  nextMidnight,
  playableChannels,
  pluginConfig,
  readConfig,
  readInput,
  renderM3u,
  renderXmltv,
  runPluginTask,
  sendProgramme,
  stashHeaders,
  stashMediaUrl,
  streamChannel,
  xml,
  xmlTime
});
